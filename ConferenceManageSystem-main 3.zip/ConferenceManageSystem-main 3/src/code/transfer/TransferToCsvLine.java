package code.transfer;

public interface TransferToCsvLine {
    String toCsvLine();
}
