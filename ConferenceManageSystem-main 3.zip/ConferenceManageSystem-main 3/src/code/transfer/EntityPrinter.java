package code.transfer;

public interface EntityPrinter {
    String getEntityLine();
}
