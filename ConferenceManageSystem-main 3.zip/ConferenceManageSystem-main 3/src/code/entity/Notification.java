package code.entity;

public class Notification {
    private String content;
}
